<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class celular extends Model
{
    protected $table = "celular";
    protected $fillable = ['modelo', 'fabricante', 'preco', 'serie'];
}
