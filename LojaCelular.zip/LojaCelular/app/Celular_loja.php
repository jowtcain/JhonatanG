<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Celular_loja extends Model
{
    protected $table = 'celular_loja';
    protected $fillable = ['celular_id', 'loja_id'];
}
